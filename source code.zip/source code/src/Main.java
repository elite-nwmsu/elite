/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S525724
 */
import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.GraphicsConfiguration;
import java.awt.GraphicsDevice;
import java.awt.GraphicsEnvironment;
import java.awt.HeadlessException;
import java.awt.Image;
import java.awt.Transparency;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.awt.image.ColorModel;
import java.awt.image.PixelGrabber;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.Queue;
import java.util.Random;
import java.util.Scanner;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import com.sun.org.apache.bcel.internal.generic.NEW;
import java.awt.Point;

final public class Main {

    JFrame frame;
    DrawPanel drawPanel;
    JLabel speed_text;

    long startTime;
    boolean flag = false;

    int freightX = 40, freightY = 825;
    boolean fup = false, fdown = false, fleft = false, fright = true, fcorner = false;

    double posX = 40, posY = 35;
    double speed = 0.0;
    boolean tup = false, tdown = false, tleft = false, tright = true;
    int location = 0;
    Queue<Point> next = new LinkedList<Point>();
    Point nextStop;

    String[] stations = {"Boston", "Medford", "Alewife", "Melrose", "Stoneham"};
    ArrayList<String> picked_stations = new ArrayList<>();
    HashMap<String, String> sec2sta = new HashMap<>();
    HashMap<String, Integer> visited = new HashMap<>();

    HashMap<String, ArrayList<Point>> sections = new HashMap<>();
    HashMap<String, Integer> speedLimit = new HashMap<>();
    HashMap<String, Point> switches = new HashMap<>();
    String[] route;
    String current, next_section, prev;

    final int LEFT = 0, RIGHT = 1, UP = 2, DOWN = 3, CROSS_RIGHT = 4, CROSS_LEFT = 5, CROSS_RIGHT_UP = 6,
            CROSS_LEFT_UP = 7;
    int dir = RIGHT;

    Main() {
        Random rand = new Random();
        int id1 = rand.nextInt(stations.length);
        picked_stations.add(stations[id1]);
        int id2;
        while ((id2 = rand.nextInt(stations.length)) == id1);
        picked_stations.add(stations[id2]);

        visited.put(picked_stations.get(0), 0);
        visited.put(picked_stations.get(1), 0);

        sec2sta.put("S1-1", "Boston");
        sec2sta.put("S1-3", "Boston");
        sec2sta.put("S10-1", "Medford");
        sec2sta.put("S10-2", "Medford");
        sec2sta.put("S5-1", "Alewife");
        sec2sta.put("S5-2", "Alewife");
        sec2sta.put("S19-1", "Melrose");
        sec2sta.put("S19-2", "Melrose");
        sec2sta.put("S25-1", "Stoneham");
        sec2sta.put("S25-2", "Stoneham");
        sec2sta.put("S25-3", "Stoneham");
        sec2sta.put("S29-1", "Reading");
        sec2sta.put("S29-2", "Reading");
    }

    /*
	 * private int oneX = 7; private int oneY = 7;
	 * 
	 * boolean up = false; boolean down = true; boolean left = false; boolean
	 * right = true;
     */

    public static void main(String[] args) {

        new Main().go();
    }

    private void readTrackdb() {
        try {
            File file = new File("trackdb.txt");
            Scanner in = new Scanner(file);
            while (in.hasNextLine()) {
                String line = in.nextLine();
                // System.out.println(line);
                String[] tokens = line.trim().split(" ");
                if (tokens[0].contains("SW")) {
                    String[] vals = tokens[1].trim().split(",");
                    int x = Integer.valueOf(vals[0]);
                    int y = Integer.valueOf(vals[1]);
                    Point p = new Point(x, y);
                    switches.put(tokens[0], p);
                } else {
                    String[] vals = tokens[1].trim().split(";");
                    ArrayList<Point> points = new ArrayList<>();
                    for (int i = 0; i < vals.length; ++i) {
                        String[] vals2 = vals[i].trim().split(",");
                        int x = Integer.valueOf(vals2[0]);
                        int y = Integer.valueOf(vals2[1]);
                        Point p = new Point(x, y);
                        points.add(p);
                    }
                    int speed = Integer.valueOf(tokens[2].trim());
                    sections.put(tokens[0], points);
                    speedLimit.put(tokens[0], speed);
                }
            }
            in.close();
            in = new Scanner(new File("route.txt"));
            while (in.hasNextLine()) {
                //System.out.println("Inside while");
                //System.out.print(in.nextLine());
                route = in.nextLine().trim().split(" ");
            }
            System.out.println("Route \n");
            for(String temp:route){
               // System.out.print(temp);
            }
            in.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        /*for (String name : switches.keySet()) {
			String value = switches.get(name).toString();
			System.out.println(name + " " + value);
		}
		for (String name : sections.keySet()) {
			ArrayList<Point> values = sections.get(name);
			System.out.print(name + " ");
			for (int i = 0; i < values.size(); ++i)
				System.out.print(values.get(i) + " ");
			System.out.print(speedLimit.get(name) + "\n");
		}*/
        //done
        for (String r : route) {
            System.out.print(r + " ");
        }
        System.out.println();
        for (String s : picked_stations) {
            System.out.println(s);
        }
        prev = null;
        /*current = route[location];
		// updateNext();
		nextStop = new Point(200, 50);
		next_section = "S2-1";*/
    }

    private void updateNext() {
        if (location + 1 < route.length && picked_stations.contains(sec2sta.get(route[location + 1])) && visited.get(sec2sta.get(route[location + 1])) == 0) {
            speed = 0;
            flag = true;
            startTime = System.currentTimeMillis();
            visited.put(sec2sta.get(route[location + 1]), 1);
            System.out.println("Waiting at station: " + sec2sta.get(route[location + 1]));
            return;
            /*long time = System.currentTimeMillis();
			while(System.currentTimeMillis() - time <= 2000);*/
        }
        location++;
        if (location >= route.length) {
            return;
        }
        String key = route[location];
        prev = current;
        current = key;
        speed = speedLimit.get(current) / 100.0;
        if (location + 1 < route.length) {
            next_section = route[location + 1];
        } else {
            next_section = key;
        }
        ArrayList<Point> tempPoints = sections.get(key);
        for (int i = 0; i < tempPoints.size(); ++i) {
            next.add(tempPoints.get(i));
        }
        //System.out.println("Inside update: " + current + " " + next_section);
    }

    private void go() {

        readTrackdb();

        frame = new JFrame("Train Simulator");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        drawPanel = new DrawPanel();

        frame.getContentPane().add(BorderLayout.CENTER, drawPanel);

        JPanel buttonPanel = new JPanel();
        JButton start = new JButton("Start");
        start.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                if (location < route.length) {
                    current = route[location];
                }
                // updateNext();
                if (current.equals("S1-1")) {
                    nextStop = new Point(200, 50);
                }
                if (location + 1 < route.length) {
                    next_section = route[location + 1];
                }
                speed = speedLimit.get(current) / 100.0;
            }
        });
        buttonPanel.add(start);
        JButton stop = new JButton("Stop");
        stop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                // TODO Auto-generated method stub
                speed = 0;
            }
        });
        buttonPanel.add(stop);
        speed_text = new JLabel();
        buttonPanel.add(speed_text);
        frame.getContentPane().add(BorderLayout.PAGE_END, buttonPanel);

        frame.setVisible(true);
        frame.setResizable(false);
        frame.setSize(700, 950);
        frame.setLocation(375, 55);

        //moveIt();
    }

    class DrawPanel extends JPanel {

        private BufferedImage image, track, track1, track3, track4, boston, alewife, melrose, medford, stoneham, reading;

        public DrawPanel() {

            try {
                //image = ImageIO.read(new File("train.jpg"));
                track = ImageIO.read(new File("track.png"));
                track1 = ImageIO.read(new File("track1.png"));
                track3 = ImageIO.read(new File("track3.png"));
                track4 = ImageIO.read(new File("track4.png"));
                boston = ImageIO.read(new File("boston.png"));
                alewife = ImageIO.read(new File("alewife.png"));
                melrose = ImageIO.read(new File("melrose.png"));
                medford = ImageIO.read(new File("medford.png"));
                stoneham = ImageIO.read(new File("stoneham.png"));
                reading = ImageIO.read(new File("reading.png"));
            } catch (IOException e) {
                e.printStackTrace();
                System.out.println("here");
            }
        }

        public void paintComponent(Graphics g) {

            /*
			 * g.setColor(Color.BLUE); g.fillRect(0, 0, this.getWidth(),
			 * this.getHeight()); g.setColor(Color.RED); g.fillRect(3, 3,
			 * this.getWidth()-6, this.getHeight()-6);
             */
            g.setColor(Color.WHITE);
            g.fillRect(6, 6, this.getWidth() - 12, this.getHeight() - 12);
            /*
			 * g.setColor(Color.BLACK); g.fillRect(oneX, oneY, 6, 6);
             */
            // draw lines
            g.setColor(Color.BLACK);

            g.drawImage(track, 40, 40, 80, 20, this);
            g.drawImage(track, 120, 40, 80, 20, this);
            g.drawImage(track, 200, 40, 80, 20, this);
            g.drawImage(track, 280, 40, 80, 20, this);
            g.drawImage(track, 360, 40, 80, 20, this);
            g.drawImage(track, 440, 40, 80, 20, this);
            g.drawImage(track, 520, 40, 80, 20, this);
            g.drawImage(track, 600, 40, 60, 20, this);

            g.drawImage(track, 40, 830, 80, 20, this);
            g.drawImage(track, 120, 830, 80, 20, this);
            g.drawImage(track, 200, 830, 80, 20, this);
            g.drawImage(track, 280, 830, 80, 20, this);
            g.drawImage(track, 360, 830, 80, 20, this);
            g.drawImage(track, 440, 830, 80, 20, this);
            g.drawImage(track, 520, 830, 80, 20, this);
            g.drawImage(track, 600, 830, 60, 20, this);

            g.drawImage(track, 40, 90, 80, 20, this);
            g.drawImage(track, 120, 90, 80, 20, this);

            g.drawImage(track, 40, 145, 80, 20, this);
            g.drawImage(track, 120, 145, 80, 20, this);
            g.drawImage(track, 200, 145, 80, 20, this);
            g.drawImage(track, 280, 145, 20, 20, this);

            g.drawImage(track, 350, 90, 80, 20, this);
            g.drawImage(track, 430, 90, 80, 20, this);
            g.drawImage(track, 510, 90, 80, 20, this);
            g.drawImage(track, 580, 90, 50, 20, this);

            g.drawImage(track, 395, 390, 80, 20, this);
            g.drawImage(track, 475, 390, 80, 20, this);
            g.drawImage(track, 555, 390, 95, 20, this);

            g.drawImage(track, 40, 200, 80, 20, this);
            g.drawImage(track, 120, 200, 80, 20, this);

            g.drawImage(track, 40, 290, 80, 20, this);
            g.drawImage(track, 120, 290, 80, 20, this);
            g.drawImage(track, 200, 290, 80, 20, this);
            g.drawImage(track, 280, 290, 80, 20, this);
            g.drawImage(track, 360, 290, 80, 20, this);
            g.drawImage(track, 440, 290, 80, 20, this);
            g.drawImage(track, 520, 290, 80, 20, this);
            g.drawImage(track, 600, 290, 60, 20, this);

            g.drawImage(track, 40, 445, 80, 20, this);
            g.drawImage(track, 120, 445, 80, 20, this);
            g.drawImage(track, 200, 445, 80, 20, this);
            g.drawImage(track, 280, 445, 80, 20, this);
            g.drawImage(track, 360, 445, 80, 20, this);
            g.drawImage(track, 440, 445, 80, 20, this);
            g.drawImage(track, 520, 445, 100, 20, this);

            g.drawImage(track, 400, 240, 75, 20, this);
            g.drawImage(track, 475, 240, 75, 20, this);
            g.drawImage(track, 100, 340, 75, 20, this);
            g.drawImage(track, 175, 340, 75, 20, this);

            g.drawImage(track, 400, 495, 80, 20, this);
            g.drawImage(track, 480, 495, 70, 20, this);

            g.drawImage(track, 30, 495, 70, 20, this);
            g.drawImage(track, 100, 495, 70, 20, this);
            g.drawImage(track, 170, 495, 70, 20, this);
            g.drawImage(track, 240, 495, 60, 20, this);

            g.drawImage(track, 80, 645, 80, 20, this);
            g.drawImage(track, 160, 645, 80, 20, this);
            g.drawImage(track, 240, 645, 80, 20, this);
            g.drawImage(track, 320, 645, 80, 20, this);
            g.drawImage(track, 400, 645, 80, 20, this);
            g.drawImage(track, 480, 645, 60, 20, this);
            g.drawImage(track, 540, 645, 95, 20, this);

            g.drawImage(track, 450, 590, 100, 20, this);

            g.drawImage(track, 50, 690, 80, 20, this);
            g.drawImage(track, 130, 690, 80, 20, this);
            g.drawImage(track, 210, 690, 90, 20, this);

            g.drawImage(track, 50, 780, 80, 20, this);
            g.drawImage(track, 130, 780, 80, 20, this);
            g.drawImage(track, 210, 780, 80, 20, this);
            g.drawImage(track, 280, 780, 80, 20, this);
            g.drawImage(track, 350, 780, 80, 20, this);
            g.drawImage(track, 430, 780, 80, 20, this);
            g.drawImage(track, 510, 780, 90, 20, this);

            g.drawImage(track, 100, 735, 75, 20, this);
            g.drawImage(track, 175, 735, 75, 20, this);

            g.drawImage(track, 500, 810, 100, 20, this);

            g.drawImage(track1, 615, 105, 20, 80, this);
            g.drawImage(track1, 645, 55, 20, 80, this);
            g.drawImage(track1, 645, 120, 20, 80, this);
            g.drawImage(track1, 645, 200, 20, 100, this);
            g.drawImage(track1, 35, 300, 20, 80, this);
            g.drawImage(track1, 35, 370, 20, 80, this);

            g.drawImage(track1, 645, 395, 20, 80, this);
            g.drawImage(track1, 645, 475, 20, 80, this);
            g.drawImage(track1, 645, 555, 20, 80, this);
            g.drawImage(track1, 645, 635, 20, 80, this);
            g.drawImage(track1, 645, 715, 20, 80, this);
            g.drawImage(track1, 645, 795, 20, 45, this);

            g.drawImage(track1, 30, 500, 20, 80, this);
            g.drawImage(track1, 30, 580, 20, 80, this);
            g.drawImage(track1, 30, 640, 20, 80, this);
            g.drawImage(track1, 30, 720, 20, 80, this);
            g.drawImage(track1, 30, 800, 20, 40, this);

            g.drawImage(track1, 620, 450, 20, 80, this);
            g.drawImage(track1, 620, 530, 20, 80, this);
            g.drawImage(track1, 620, 610, 20, 40, this);

            g.drawImage(track1, 45, 700, 20, 90, this);

            g.drawImage(track3, 200, 85, 10, 20, this);
            g.drawImage(track3, 205, 80, 10, 20, this);
            g.drawImage(track3, 210, 75, 10, 20, this);
            g.drawImage(track3, 215, 70, 10, 20, this);
            g.drawImage(track3, 220, 65, 10, 20, this);
            g.drawImage(track3, 225, 60, 10, 20, this);
            g.drawImage(track3, 230, 55, 10, 20, this);
            g.drawImage(track3, 235, 50, 10, 20, this);

            g.drawImage(track3, 200, 195, 10, 20, this);
            g.drawImage(track3, 205, 190, 10, 20, this);
            g.drawImage(track3, 210, 185, 10, 20, this);
            g.drawImage(track3, 215, 180, 10, 20, this);
            g.drawImage(track3, 220, 175, 10, 20, this);
            g.drawImage(track3, 225, 170, 10, 20, this);
            g.drawImage(track3, 230, 165, 10, 20, this);
            g.drawImage(track3, 235, 160, 10, 20, this);
            g.drawImage(track3, 240, 155, 10, 20, this);
            g.drawImage(track3, 245, 150, 10, 20, this);

            g.drawImage(track3, 300, 140, 10, 20, this);
            g.drawImage(track3, 305, 135, 10, 20, this);
            g.drawImage(track3, 310, 130, 10, 20, this);
            g.drawImage(track3, 315, 125, 10, 20, this);
            g.drawImage(track3, 320, 120, 10, 20, this);
            g.drawImage(track3, 325, 115, 10, 20, this);
            g.drawImage(track3, 330, 110, 10, 20, this);
            g.drawImage(track3, 335, 105, 10, 20, this);
            g.drawImage(track3, 340, 100, 10, 20, this);

            g.drawImage(track3, 355, 285, 10, 20, this);
            g.drawImage(track3, 360, 280, 10, 20, this);
            g.drawImage(track3, 365, 275, 10, 20, this);
            g.drawImage(track3, 370, 270, 10, 20, this);
            g.drawImage(track3, 375, 265, 10, 20, this);
            g.drawImage(track3, 380, 260, 10, 20, this);
            g.drawImage(track3, 385, 255, 10, 20, this);
            g.drawImage(track3, 390, 250, 10, 20, this);

            g.drawImage(track3, 250, 335, 10, 20, this);
            g.drawImage(track3, 255, 330, 10, 20, this);
            g.drawImage(track3, 260, 325, 10, 20, this);
            g.drawImage(track3, 265, 320, 10, 20, this);
            g.drawImage(track3, 270, 315, 10, 20, this);
            g.drawImage(track3, 275, 310, 10, 20, this);
            g.drawImage(track3, 280, 305, 10, 20, this);
            g.drawImage(track3, 285, 300, 10, 20, this);

            g.drawImage(track3, 350, 440, 10, 20, this);
            g.drawImage(track3, 355, 435, 10, 20, this);
            g.drawImage(track3, 360, 430, 10, 20, this);
            g.drawImage(track3, 365, 425, 10, 20, this);
            g.drawImage(track3, 370, 420, 10, 20, this);
            g.drawImage(track3, 375, 415, 10, 20, this);
            g.drawImage(track3, 380, 410, 10, 20, this);
            g.drawImage(track3, 385, 405, 10, 20, this);
            g.drawImage(track3, 390, 400, 10, 20, this);
            g.drawImage(track3, 395, 395, 10, 20, this);

            g.drawImage(track3, 553, 490, 10, 20, this);
            g.drawImage(track3, 556, 485, 10, 20, this);
            g.drawImage(track3, 559, 480, 10, 20, this);
            g.drawImage(track3, 562, 475, 10, 20, this);
            g.drawImage(track3, 565, 470, 10, 20, this);
            g.drawImage(track3, 568, 465, 10, 20, this);
            g.drawImage(track3, 571, 460, 10, 20, this);
            g.drawImage(track3, 574, 455, 10, 20, this);
            g.drawImage(track3, 577, 450, 10, 20, this);

            g.drawImage(track3, 300, 490, 10, 20, this);
            g.drawImage(track3, 305, 485, 10, 20, this);
            g.drawImage(track3, 310, 480, 10, 20, this);
            g.drawImage(track3, 315, 475, 10, 20, this);
            g.drawImage(track3, 320, 470, 10, 20, this);
            g.drawImage(track3, 325, 465, 10, 20, this);
            g.drawImage(track3, 330, 460, 10, 20, this);
            g.drawImage(track3, 335, 455, 10, 20, this);
            g.drawImage(track3, 340, 450, 10, 20, this);

            g.drawImage(track3, 400, 640, 10, 20, this);
            g.drawImage(track3, 405, 635, 10, 20, this);
            g.drawImage(track3, 410, 630, 10, 20, this);
            g.drawImage(track3, 415, 625, 10, 20, this);
            g.drawImage(track3, 420, 620, 10, 20, this);
            g.drawImage(track3, 425, 615, 10, 20, this);
            g.drawImage(track3, 430, 610, 10, 20, this);
            g.drawImage(track3, 435, 605, 10, 20, this);
            g.drawImage(track3, 440, 600, 10, 20, this);

            g.drawImage(track3, 300, 690, 10, 20, this);
            g.drawImage(track3, 305, 685, 10, 20, this);
            g.drawImage(track3, 310, 680, 10, 20, this);
            g.drawImage(track3, 315, 675, 10, 20, this);
            g.drawImage(track3, 320, 670, 10, 20, this);
            g.drawImage(track3, 325, 665, 10, 20, this);
            g.drawImage(track3, 330, 660, 10, 20, this);
            g.drawImage(track3, 335, 655, 10, 20, this);
            g.drawImage(track3, 340, 650, 10, 20, this);

            g.drawImage(track3, 250, 730, 10, 20, this);
            g.drawImage(track3, 255, 725, 10, 20, this);
            g.drawImage(track3, 260, 720, 10, 20, this);
            g.drawImage(track3, 265, 715, 10, 20, this);
            g.drawImage(track3, 270, 710, 10, 20, this);
            g.drawImage(track3, 275, 705, 10, 20, this);
            g.drawImage(track3, 280, 700, 10, 20, this);
            g.drawImage(track3, 335, 655, 10, 20, this);

            g.drawImage(track3, 405, 85, 10, 20, this);
            g.drawImage(track3, 410, 80, 10, 20, this);
            g.drawImage(track3, 415, 75, 10, 20, this);
            g.drawImage(track3, 420, 70, 10, 20, this);
            g.drawImage(track3, 425, 65, 10, 20, this);
            g.drawImage(track3, 430, 60, 10, 20, this);
            g.drawImage(track3, 435, 55, 10, 20, this);
            g.drawImage(track3, 440, 50, 10, 20, this);

            g.drawImage(track3, 505, 85, 10, 20, this);
            g.drawImage(track3, 510, 80, 10, 20, this);
            g.drawImage(track3, 515, 75, 10, 20, this);
            g.drawImage(track3, 520, 70, 10, 20, this);
            g.drawImage(track3, 525, 65, 10, 20, this);
            g.drawImage(track3, 530, 60, 10, 20, this);
            g.drawImage(track3, 535, 55, 10, 20, this);
            g.drawImage(track3, 540, 50, 10, 20, this);

            g.drawImage(track4, 625, 175, 10, 20, this);
            g.drawImage(track4, 630, 180, 10, 20, this);
            g.drawImage(track4, 635, 185, 10, 20, this);
            g.drawImage(track4, 640, 190, 10, 20, this);
            g.drawImage(track4, 645, 195, 10, 20, this);

            g.drawImage(track4, 405, 50, 10, 20, this);
            g.drawImage(track4, 410, 55, 10, 20, this);
            g.drawImage(track4, 415, 60, 10, 20, this);
            g.drawImage(track4, 420, 65, 10, 20, this);
            g.drawImage(track4, 425, 70, 10, 20, this);
            g.drawImage(track4, 430, 75, 10, 20, this);
            g.drawImage(track4, 435, 80, 10, 20, this);
            g.drawImage(track4, 440, 85, 10, 20, this);

            g.drawImage(track4, 505, 50, 10, 20, this);
            g.drawImage(track4, 510, 55, 10, 20, this);
            g.drawImage(track4, 515, 60, 10, 20, this);
            g.drawImage(track4, 520, 65, 10, 20, this);
            g.drawImage(track4, 525, 70, 10, 20, this);
            g.drawImage(track4, 530, 75, 10, 20, this);
            g.drawImage(track4, 535, 80, 10, 20, this);
            g.drawImage(track4, 540, 85, 10, 20, this);

            g.drawImage(track4, 550, 245, 10, 20, this);
            g.drawImage(track4, 555, 250, 10, 20, this);
            g.drawImage(track4, 560, 255, 10, 20, this);
            g.drawImage(track4, 565, 260, 10, 20, this);
            g.drawImage(track4, 570, 265, 10, 20, this);
            g.drawImage(track4, 575, 270, 10, 20, this);
            g.drawImage(track4, 580, 275, 10, 20, this);
            g.drawImage(track4, 585, 280, 10, 20, this);
            g.drawImage(track4, 590, 285, 10, 20, this);

            g.drawImage(track4, 550, 595, 10, 20, this);
            g.drawImage(track4, 555, 600, 10, 20, this);
            g.drawImage(track4, 560, 605, 10, 20, this);
            g.drawImage(track4, 565, 610, 10, 20, this);
            g.drawImage(track4, 570, 615, 10, 20, this);
            g.drawImage(track4, 575, 620, 10, 20, this);
            g.drawImage(track4, 580, 625, 10, 20, this);
            g.drawImage(track4, 585, 630, 10, 20, this);
            g.drawImage(track4, 590, 635, 10, 20, this);

            g.drawImage(track4, 480, 790, 10, 20, this);
            g.drawImage(track4, 485, 795, 10, 20, this);
            g.drawImage(track4, 490, 800, 10, 20, this);
            g.drawImage(track4, 495, 805, 10, 20, this);

            g.drawImage(track4, 60, 300, 10, 20, this);
            g.drawImage(track4, 65, 305, 10, 20, this);
            g.drawImage(track4, 70, 310, 10, 20, this);
            g.drawImage(track4, 75, 315, 10, 20, this);
            g.drawImage(track4, 80, 320, 10, 20, this);
            g.drawImage(track4, 85, 325, 10, 20, this);
            g.drawImage(track4, 90, 330, 10, 20, this);
            g.drawImage(track4, 95, 335, 10, 20, this);

            g.drawImage(track4, 370, 450, 10, 20, this);
            g.drawImage(track4, 373, 455, 10, 20, this);
            g.drawImage(track4, 376, 460, 10, 20, this);
            g.drawImage(track4, 379, 465, 10, 20, this);
            g.drawImage(track4, 382, 470, 10, 20, this);
            g.drawImage(track4, 385, 475, 10, 20, this);
            g.drawImage(track4, 388, 480, 10, 20, this);
            g.drawImage(track4, 391, 485, 10, 20, this);

            g.drawImage(track4, 80, 700, 10, 20, this);
            g.drawImage(track4, 83, 705, 10, 20, this);
            g.drawImage(track4, 86, 710, 10, 20, this);
            g.drawImage(track4, 89, 715, 10, 20, this);
            g.drawImage(track4, 92, 720, 10, 20, this);
            g.drawImage(track4, 95, 725, 10, 20, this);

            /*
			 * g.drawLine(40, 50, 650, 50); g.drawLine(40, 45, 655, 45);
			 * 
			 * g.drawLine(40, 100, 200, 100); g.drawLine(40, 95, 200, 95);
             */

 /*g.drawLine(200, 100, 250, 50);
			g.drawLine(200, 95, 250, 45);*/

 /*
			 * g.drawLine(40, 150, 300, 150); g.drawLine(40, 145, 300, 145);
			 

			g.drawLine(350, 100, 300, 150);
			g.drawLine(350, 95, 300, 145);
             */
 /*
			 * g.drawLine(350, 100, 620, 100); g.drawLine(350, 95, 625, 95);
             */

 /*
			 * g.drawLine(620, 180, 620, 100); g.drawLine(625, 175, 625, 95);
			 

			g.drawLine(620, 180, 650, 200);
			g.drawLine(625, 175, 655, 195);
             */
 /*
			 * g.drawLine(650, 50, 650, 200); g.drawLine(655, 45, 655, 200);
			 * 
			 * g.drawLine(40, 200, 200, 200); g.drawLine(40, 195, 200, 195);
			 

			g.drawLine(200, 200, 250, 150);
			g.drawLine(200, 195, 250, 145);
             */
 /*
			 * g.drawLine(650, 200, 650, 300); g.drawLine(655, 195, 655, 295);
             */

 /*g.drawLine(40, 300, 650, 300);
			g.drawLine(45, 295, 655, 295);

			g.drawLine(350, 300, 400, 250);
			g.drawLine(350, 295, 400, 245);
			
			g.drawLine(400, 250, 550, 250);
			g.drawLine(400, 245, 550, 245);
             */
 /*g.drawLine(250, 350, 100, 350);
			g.drawLine(250, 345, 100, 345);

			g.drawLine(300, 300, 250, 350);
			g.drawLine(300, 295, 250, 345);
			
			g.drawLine(40, 300, 40, 450);
			g.drawLine(45, 295, 45, 445);
			
			g.drawLine(620, 450, 40, 450);
			g.drawLine(625, 445, 45, 445);
			
			g.drawLine(350, 450, 400, 400);
			g.drawLine(350, 445, 400, 395);
			g.drawLine(550, 500, 400, 500);
			g.drawLine(550, 495, 400, 495);
		
			g.drawLine(550, 500, 580, 450);
			g.drawLine(550, 495, 580, 445);
			
			g.drawLine(650, 400, 650, 830);
			g.drawLine(655, 395, 655, 835);
			
			g.drawLine(40, 830, 650, 830);
			g.drawLine(35, 835, 655, 835);
			 
			g.drawLine(40, 830, 40, 500);
			g.drawLine(35, 835, 35, 495);

			g.drawLine(40, 500, 300, 500);
			g.drawLine(35, 495, 300, 495);

			g.drawLine(350, 450, 300, 500);
			g.drawLine(350, 445, 300, 495);

			g.drawLine(620, 450, 620, 650);
			g.drawLine(625, 445, 625, 645);

			g.drawLine(80, 650, 620, 650);
			g.drawLine(80, 645, 625, 645);

			g.drawLine(450, 600, 550, 600);
			g.drawLine(450, 595, 550, 595);

			g.drawLine(450, 600, 400, 650);
			g.drawLine(450, 595, 400, 645);

			g.drawLine(350, 650, 300, 700);
			g.drawLine(350, 645, 300, 695);

			g.drawLine(50, 700, 300, 700);
			g.drawLine(55, 695, 300, 695);

			g.drawLine(50, 700, 50, 780);
			g.drawLine(55, 695, 55, 775);

			g.drawLine(600, 780, 50, 780);
			g.drawLine(600, 775, 55, 775);

			g.drawLine(280, 700, 250, 730);
			g.drawLine(280, 695, 250, 725);
			g.drawLine(100, 730, 250, 730);
			g.drawLine(100, 725, 250, 725);
			g.drawLine(400, 100, 450, 50);
			g.drawLine(400, 95, 450, 45);
			g.drawLine(500, 100, 550, 50);
			g.drawLine(500, 95, 550, 45);
			g.drawLine(600, 810, 500, 810);
			g.drawLine(595, 805, 495, 805);
			
			g.drawLine(400, 45, 450, 95);
			g.drawLine(400, 50, 450, 100);
			
			g.drawLine(500, 45, 550, 95);
			g.drawLine(500, 50, 550, 100);
			
			g.drawLine(600, 300, 550, 250);
			g.drawLine(600, 295, 550, 245);
			g.drawLine(50, 300, 100, 350);
			g.drawLine(50, 295, 100, 345);
			g.drawLine(370, 450, 400, 500);
			g.drawLine(370, 445, 400, 495);
			g.drawLine(600, 650, 550, 600);
			g.drawLine(600, 645, 550, 595);
			g.drawLine(100, 730, 80, 700);
			g.drawLine(100, 725, 80, 695);
			g.drawLine(450, 780, 500, 810);
			g.drawLine(445, 775, 495, 805);
             */
            g.setColor(Color.RED);

            g.drawImage(image, freightX, freightY, this);

            g.drawImage(image, (int) posX, (int) posY, this);

            g.drawImage(boston, 40, 70, this);
            g.drawImage(boston, 40, 170, this);

            g.drawImage(alewife, 570, 70, this);
            g.drawImage(medford, 130, 310, this);
            g.drawImage(melrose, 440, 470, this);
            g.drawImage(stoneham, 130, 660, this);
            g.drawImage(stoneham, 130, 710, this);
            g.drawImage(reading, 510, 798, this);
            /*
			 * if (fright || fleft) g.fillRect(freightX, freightY, 30, 30); else
			 * if (fup || fdown) g.fillRect(freightX, freightY, 30, 30);
             */

        }
    }

    /*private void updateDir() {

		if (current.equals("S2-1")) {
			if (prev.equals("S1-1"))
				dir = RIGHT;
		} else if (current.equals("S3-1")) {
			if (prev.equals("S2-1"))
				dir = RIGHT;
		} else if (current.equals("S4-1")) {
			if (prev.equals("S3-1"))
				dir = RIGHT;
		} else if (current.equals("S5-1")) {
			if (prev.equals("S4-1"))
				dir = RIGHT;
		} else if (current.equals("S5-2")) {
			if (prev.equals("S4-1")) {
				dir = CROSS_RIGHT;
				if (posX >= 550 || posY >= 100)
					dir = RIGHT;
			}

		} else if (current.equals("S6-2")) {
			if (prev.equals("S5-2")) {
				dir = DOWN;
				if (posX >= 620 && posY >= 180)
					dir = CROSS_RIGHT;
			}

		} else if (current.equals("S7-1")) {
			if (prev.equals("S6-1") || prev.equals("S6-2")) {
				dir = DOWN;
				if (posY >= 300)
					dir = LEFT;
			}

		} else if (current.equals("S8-1")) {
			if (prev.equals("S7-1")) {
				dir = CROSS_LEFT_UP;
				if (posY <= 250 || posX <= 550)
					dir = LEFT;
				if (posX <= 400)
					dir = CROSS_LEFT;
			}

		} else if (current.equals("S8-2")) {
			if (prev.equals("S7-1")) {
				dir = LEFT;
			}

		} else if (current.equals("S9-1")) {
			if (prev.equals("S8-1") || prev.equals("S8-2")) {
				dir = LEFT;
			}
		} else if (current.equals("S10-1")) {
			if (prev.equals("S9-1")) {
				dir = LEFT;
			}
		} else if (current.equals("S10-2")) {
			if (prev.equals("S9-1")) {
				dir = CROSS_LEFT;
				if (posY >= 350 || posX <= 250)
					dir = LEFT;
				if (posX <= 100)
					dir = CROSS_LEFT_UP;
			}
		} else if (current.equals("S11-1")) {
			if (prev.equals("S10-1") || prev.equals("S10-2")) {
				dir = LEFT;
				if (posX <= 40)
					dir = DOWN;
			}
		} else if (current.equals("S12-1")) {
			if (prev.equals("S11-1")) {
				dir = RIGHT;
			}
		} else if (current.equals("S13-1")) {
			if (prev.equals("S12-1") || prev.equals("S14-1")) {
				dir = CROSS_RIGHT;
				if (posX >= 400 || posY <= 400)
					dir = RIGHT;
			}
		} else if (current.equals("S16-1")) {
			if (prev.equals("S17-1")) {
				dir = DOWN;
				if (posY >= 830)
					dir = LEFT;
				if (posX <= 40)
					dir = UP;
			}
		} else if (current.equals("S17-1")) {
			if (prev.equals("S13-1")) {
				dir = RIGHT;
				if (posX >= 650)
					dir = DOWN;
			}
		} else if (current.equals("S18-1")) {
			if (prev.equals("S12-1") || prev.equals("S13-1") || prev.equals("S14-1")) {
				dir = RIGHT;
			}
		} else if (current.equals("S19-1")) {
			if (prev.equals("S18-1")) {
				dir = RIGHT;
			}
		} else if (current.equals("S19-2")) {
			if (prev.equals("S18-1")) {
				dir = CROSS_RIGHT;
				if (posX >= 400 || posY >= 500)
					dir = RIGHT;
				if (posX >= 550)
					dir = CROSS_RIGHT_UP;
			}
		} else if (current.equals("S20-1")) {
			if (prev.equals("S19-1") || prev.equals("S19-2")) {
				dir = RIGHT;
				if (posX >= 620)
					dir = DOWN;
			}
		} else if (current.equals("S21-1")) {
			if (prev.equals("S20-1")) {
				dir = DOWN;
				if (posY >= 650)
					dir = LEFT;
			}
		} else if (current.equals("S22-1")) {
			if (prev.equals("S21-1")) {
				dir = CROSS_LEFT_UP;
				if (posX <= 550 || posY <= 500)
					dir = LEFT;
				if (posX <= 450)
					dir = CROSS_LEFT;
			}
		} else if (current.equals("S22-2")) {
			if (prev.equals("S21-1")) {
				dir = LEFT;
			}
		} else if (current.equals("S23-1")) {
			if (prev.equals("S22-1") || prev.equals("S22-2")) {
				dir = LEFT;
			}
		} else if (current.equals("S24-1")) {
			if (prev.equals("S23-1")) {
				dir = CROSS_LEFT;
				if (posX <= 300 || posY >= 700)
					dir = LEFT;
			}
		} else if (current.equals("S25-1")) {
			if (prev.equals("S23-1")) {
				dir = LEFT;
			}
		} else if (current.equals("S25-2")) {
			if (prev.equals("S24-1")) {
				dir = LEFT;
			}
		} else if (current.equals("S25-3")) {
			if (prev.equals("S24-1")) {
				dir = CROSS_LEFT;
				if (posX <= 250 || posY >= 730)
					dir = LEFT;
				if (posX <= 100)
					dir = CROSS_LEFT_UP;
			}
		} else if (current.equals("S26-1")) {
			if (prev.equals("S25-2") || prev.equals("S25-3")) {
				dir = LEFT;
				if (posX <= 50 || posY >= 730)
					dir = DOWN;
				if (posY >= 780)
					dir = RIGHT;
			}
		} else if (current.equals("S27-1")) {
			if (prev.equals("S26-1")) {
				dir = RIGHT;
			}
		} else if (current.equals("S28-1")) {
			if (prev.equals("S27-1")) {
				dir = RIGHT;
			}
		} else if (current.equals("S29-1")) {
			if (prev.equals("S28-1")) {
				dir = RIGHT;
			}
		} else if (current.equals("S29-2")) {
			if (prev.equals("S28-1")) {
				dir = CROSS_RIGHT;
				if (posX >= 500 || posY >= 810)
					dir = RIGHT;
			}
		}

	}

	private void moveIt() {
		while (true) {
			
			speed_text.setText("Speed: " + (int) (speed*100));
			
			if (fright) {
				freightX++;
				if (freightX > 640) {
					fright = false;
					fup = true;
				}
			}
			if (fup) {
				freightY--;
				if (freightY < 390) {
					fup = false;
					fleft = true;
				}
			}
			if (fleft) {
				freightX--;
				if (freightX < 25) {
					fleft = false;
					fdown = true;
				} else if (freightX < 300) {
					fdown = false;
				} else if (freightX < 400) {
					fdown = true;
				}

			}
			if (fdown) {
				freightY++;
				if (freightY > 825) {
					fdown = false;
					fright = true;
				}
			}
			if (speed != 0) {
				if (location >= route.length)
					dir = -1;
				/*System.out.println(posX + " " + posY + " " + nextStop + " DIR: " + dir);
				System.out.println(current + " " + next_section);
				System.out.println(next);
				if (dir == RIGHT) {
					posX += speed;
					if (posX >= nextStop.x) {
						// posX = nextStop.x;
						if (!next.isEmpty())
							nextStop = next.poll();
						else
							updateNext();
						updateDir();
					}
				} else if (dir == LEFT) {
					posX -= speed;
					if (posX <= nextStop.x) {
						// posX = nextStop.x;
						if (!next.isEmpty())
							nextStop = next.poll();
						else
							updateNext();
						updateDir();
					}
				} else if (dir == DOWN) {
					posY += speed;
					if (posY >= nextStop.y) {
						// posY = nextStop.y;
						if (!next.isEmpty())
							nextStop = next.poll();
						else
							updateNext();
						updateDir();
					}
				} else if (dir == CROSS_RIGHT) {
					posX += speed;
					posY += speed;
					if (posY >= nextStop.y || posX >= nextStop.x) {
						// posY = nextStop.y;
						if (!next.isEmpty())
							nextStop = next.poll();
						else
							updateNext();
						updateDir();
					}
				} else if (dir == CROSS_LEFT) {
					posX -= speed;
					posY += speed;
					if (posY >= nextStop.y || posX <= nextStop.x) {
						// posY = nextStop.y;
						if (!next.isEmpty())
							nextStop = next.poll();
						else
							updateNext();
						updateDir();
					}
				} else if (dir == CROSS_LEFT_UP) {
					posX -= speed;
					posY -= speed;
					if (posY <= nextStop.y || posX <= nextStop.x) {
						// posY = nextStop.y;
						if (!next.isEmpty())
							nextStop = next.poll();
						else
							updateNext();
						updateDir();
					}
				}
			}
			else {
				if (flag) {
					if (System.currentTimeMillis() - startTime >= 2000) {
						flag = false;
						System.out.println("Leaving station");
						updateNext();
					}
				}
			}
			try {
				Thread.sleep(10);
			} catch (Exception exc) {
			}
			frame.repaint();
		}
	}

		class Section {
		String id;
		boolean sw;
		String next, current, next1, prev1;

	}

	class Point {
		public int x, y;

		public Point(int x, int y) {
			// TODO Auto-generated constructor stub
			this.x = x;
			this.y = y;
		}

		@Override
		public String toString() {
			// TODO Auto-generated method stub
			String s = "x: " + x + " y: " + y;
			return s;
		}
	}*/
}
