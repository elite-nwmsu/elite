
import java.awt.Point;
import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Scanner;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author S525700
 */
public class TrackDatabase {
    
    private HashMap<String, Point> switches = new HashMap<>();
    private HashMap<String, ArrayList<Point>> sections = new HashMap<>();
    private HashMap<String, Integer> speedLimit = new HashMap<>();
    private String[] route;
    private ArrayList<String> picked_stations = new ArrayList<>();
    private String prev;
    
    public HashMap<String, ArrayList<Point>> getSections() {
        return sections;
    }

    public void setSections(HashMap<String, ArrayList<Point>> sections) {
        this.sections = sections;
    }

    public HashMap<String, Integer> getSpeedLimit() {
        return speedLimit;
    }

    public void setSpeedLimit(HashMap<String, Integer> speedLimit) {
        this.speedLimit = speedLimit;
    }

    public HashMap<String, Point> getSwitches() {
        return switches;
    }

    public void setSwitches(HashMap<String, Point> switches) {
        this.switches = switches;
    }
    
    
    private void readTrackdb() {
        try {
            File file = new File("trackdb.txt");
            Scanner in = new Scanner(file);
            while (in.hasNextLine()) {
                String line = in.nextLine();
                // System.out.println(line);
                String[] tokens = line.trim().split(" ");
                if (tokens[0].contains("SW")) {
                    String[] vals = tokens[1].trim().split(",");
                    int x = Integer.valueOf(vals[0]);
                    int y = Integer.valueOf(vals[1]);
                    Point p = new Point(x, y);
                    switches.put(tokens[0], p);
                } else {
                    String[] vals = tokens[1].trim().split(";");
                    ArrayList<Point> points = new ArrayList<>();
                    for (int i = 0; i < vals.length; ++i) {
                        String[] vals2 = vals[i].trim().split(",");
                        int x = Integer.valueOf(vals2[0]);
                        int y = Integer.valueOf(vals2[1]);
                        Point p = new Point(x, y);
                        points.add(p);
                    }
                    int speed = Integer.valueOf(tokens[2].trim());
                    sections.put(tokens[0], points);
                    speedLimit.put(tokens[0], speed);
                }
            }
            in.close();
            in = new Scanner(new File("route.txt"));
            while (in.hasNextLine()) {
                route = in.nextLine().trim().split(" ");
            }
            System.out.println(route);
            in.close();
        } catch (FileNotFoundException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        /*for (String name : switches.keySet()) {
			String value = switches.get(name).toString();
			System.out.println(name + " " + value);
		}
		for (String name : sections.keySet()) {
			ArrayList<Point> values = sections.get(name);
			System.out.print(name + " ");
			for (int i = 0; i < values.size(); ++i)
				System.out.print(values.get(i) + " ");
			System.out.print(speedLimit.get(name) + "\n");
		}*/
        for (String r : route) {
            System.out.print(r + " ");
        }
        System.out.println();
        for (String s : picked_stations) {
            System.out.println(s);
        }
        prev = null;
        /*current = route[location];
		// updateNext();
		nextStop = new Point(200, 50);
		next_section = "S2-1";*/
    }
}
